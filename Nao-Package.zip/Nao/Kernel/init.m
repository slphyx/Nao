(* Mathematica Init File *)

Get[ "Nao`Nao`"]