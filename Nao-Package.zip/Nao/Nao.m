(* Mathematica Package *)

(* Created by the Wolfram Workbench 3 May 2559 *)

BeginPackage["Nao`"]
(* Exported symbols added here with SymbolName::usage *) 
NaoDiff::usage = "NaoDiff[fastafile, outfile] takes the columns of sequences that the reference is different from the rest and export as an Excel file."


Begin["`Private`"]
(* Implementation of the package *)

(* to find the position indexes of the beginning of each sequence in \
the file *)
PosInFasta[txtlist_] := Block[{tmp, hd, biglen, grp, indx},
   biglen = Length@txtlist;
   (* list of the header of each sequence *)
   hd = Reap[If[StringTake[First@#, {1}] == ">", Sow[#], #] & /@ f][[
     2, 1]];
   tmp = (Position[txtlist, #] & /@ hd // Flatten)~Join~{biglen};
   Print["There are " <> ToString[Length@hd] <> 
     " sequences in the data file."];
   grp = Partition[tmp, 2, 1];
   indx = {#[[1]] + 1, #[[2]] - 1} & /@ grp;
   indx[[Length@grp, 2]] = indx[[Length@grp, 2]] + 1;
   indx
   ];
   
(* combiine all the sequences in a position-index (posindx) range *)
MakeItLong[posindx_, fasta_] := Block[{extract},
   extract = fasta[[Range @@ posindx]];
   StringJoin@Flatten@extract
   ];

(* check if the first character is different from the rest;
return false if one of the rest is diiferent *)
Compare[charls_] := Block[{ref, rest, output},
   ref = First@charls;
   rest = Rest@charls;
   output = Fold[And, (ref == #)& /@ rest];
   output
   ];

TakeCharList[bigls_, posindx_] := StringTake[#, {posindx}] & /@ bigls

ShowDiff[bigls_] := Block[{len, grpbigls},
   len = StringLength@First@bigls;
   grpbigls = {#, TakeCharList[bigls, #]} & /@ Range[len];
   Reap[If[Compare[#[[2]]] == False, Sow[#]] & /@ grpbigls][[2, 1]]
   ];

(* write the different sequence into teh excel file  *)
NaoDiff[fastafile_, outfile_] := Block[{f, posindx, bigls, tmp},
   f = Import[fastafile,"FASTA"];
   (*posindx = PosInFasta[f];*)
   (*bigls = MakeItLong[#, f] & /@ posindx;*)
   tmp = (Flatten /@ ShowDiff[f])\[Transpose];
   Export[outfile <> ".xlsx", tmp, "XLSX"]
   ];

End[]

EndPackage[]

