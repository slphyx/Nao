(* Paclet Info File *)

(* created 2560/07/03*)

Paclet[
    Name -> "Nao",
    Version -> "0.0.1",
    MathematicaVersion -> "6+",
    Creator -> "Sompob Saralamba",
    Extensions -> 
        {
            {"Documentation", Language -> "English"}
        }
]


